import numpy as np



lst1=np.load('svhn_tmp.npy')
lst2=np.load('c10_tmp.npy')

print(np.mean(lst1))
print(np.mean(lst2))