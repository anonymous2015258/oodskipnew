import torch
from torch import nn
from tqdm import tqdm
import time
from sklearn import metrics

DOUBLE_INFO = torch.finfo(torch.double)
FLOAT_INFO = torch.finfo(torch.float32)
JITTERS = [0, DOUBLE_INFO.tiny] + [10 ** exp for exp in range(-308, 0, 1)]
# JITTERS = [1e-3]

def centered_cov_torch(x):
    n = x.shape[0]
    res = 1 / (n - 1) * x.t().mm(x)
    return res


def get_embeddings(
    net, output_id, loader: torch.utils.data.DataLoader, dtype, device, storage_device,
):
    # determine embedding length
    data, label = next(x for x in loader)
    data = data.to(device)   # tiny: 128,3,64,64;
    label = label.to(device) # tiny: 128,;
    if isinstance(net, nn.DataParallel):
        out = net.module(data)  # add inter_output to extract the embeddings
        out = net.module.embeddings[output_id]
    else:
        out = net(data)  # tiny: 7 tensors, [128,200]s
        out = net.embeddings[output_id]
    num_dim = out.shape[1]
    print("******** the embedding num_dim:", num_dim)
    num_samples = len(loader.dataset)
    embeddings = torch.empty((num_samples, num_dim), dtype=dtype, device=storage_device)
    labels = torch.empty(num_samples, dtype=torch.int, device=storage_device)

    with torch.no_grad():
        start = 0
        for data, label in tqdm(loader):
            data = data.to(device)
            label = label.to(device)

            if isinstance(net, nn.DataParallel):
                out = net.module(data)
                out = net.module.embeddings[output_id]
            else:
                out = net(data)
                out = net.embeddings[output_id]

            end = start + len(data)
            embeddings[start:end].copy_(out, non_blocking=True)
            labels[start:end].copy_(label, non_blocking=True)
            start = end

    return embeddings, labels


def gmm_forward(net, output_id, gaussians_model, data_B_X):
    #data_B_X = torch.autograd.Variable(data_B_X, requires_grad=True)
    #print(data_B_X.requires_grad)
    if isinstance(net, nn.DataParallel):
        features_B_Z = net.module(data_B_X)
        features_B_Z = net.module.embeddings[output_id]
    else:
        #print(data_B_X.size())
        features_B_Z = net(data_B_X)
        features_B_Z = net.embeddings[output_id]
    #features_B_Z[0][0].backward()
    #print(features_B_Z[0][0])
    #print(data_B_X.grad)
    #features_B_Z = features_B_Z.to("cpu")
    #features_B_Z=torch.autograd.Variable(features_B_Z,requires_grad=True)
    # print(features_B_Z[:, None, :].shape) # 128,1,1024, tiny: 128*1*256
    #print(features_B_Z.shape)
    log_probs_B_Y = gaussians_model.log_prob(features_B_Z[:, None, :])
    #log_probs_B_Y=torch.add(log_probs_B_Y,0.0001)
    #print(features_B_Z[:, None, :].shape)
    #log_probs_B_Y = gaussians_model.log_prob(features_B_Z)
    # print(log_probs_B_Y.shape)  # 128, 10, tiny: 128*200
    #print(log_probs_B_Y[0][0])
    #log_probs_B_Y[0][0].backward()


    return log_probs_B_Y, features_B_Z


def gmm_evaluate(net, output_id, gaussians_model, loader, device, num_classes, storage_device):
    num_samples = len(loader.dataset)
    #num_samples = len(loader)
    #logits_N_C = torch.empty((num_samples, num_classes), dtype=torch.float, device='cpu')
    #logits_N_C = torch.empty((num_samples, num_classes), dtype=torch.float, device='cpu')
    logits_N_C=[]
    labels_N = torch.empty(num_samples, dtype=torch.int, device='cpu')  #
    # 26032,10
    feats=[]

    #with torch.no_grad():
    start = 0
    for data, label in tqdm(loader):
        data = data.to(device)  # Tiny: 128,3,64,64; SVHN: 128,3,32,32
        #data = torch.autograd.Variable(data, requires_grad=True).to(device)
        label = label.to(device)

        logit_B_C, features_B_Z = gmm_forward(net, output_id, gaussians_model, data)
        #feats.extend(features_B_Z.tolist())

        end = start + len(data)
        #print(logits_N_C.get_device())
        #logits_N_C[start:end].copy_(logit_B_C, non_blocking=True)
        #labels_N[start:end].copy_(label, non_blocking=True)
        logits_N_C.extend(logit_B_C.tolist())
        start = end

    #return logits_N_C, labels_N, feats
    print(torch.tensor(logits_N_C).size())
    return torch.tensor(logits_N_C), labels_N


def gmm_evaluate_adversarial(net, output_id, gaussians_model, loader, device, num_classes, storage_device):
    num_samples = loader.shape[0]
    #gaussians_model=gaussians_model.to(device)
    logits_N_C = torch.empty((num_samples, num_classes), dtype=torch.float, device=storage_device)
    labels_N = torch.empty(num_samples, dtype=torch.int, device=storage_device)  #
    # 100,10
    feats=[]
    #with torch.no_grad():
    data = torch.squeeze(loader, axis=1).to(torch.float32)
    #data = torch.autograd.Variable(data, requires_grad=True).to(device)
    data = data.to(device)  # Tiny: 128,3,64,64; SVHN: 128,3,32,32
    #data.retain_grad()
    logit_B_C, features_B_Z = gmm_forward(net, output_id, gaussians_model, data)
    #print(data.grad[0][0])
    # print(features_B_Z.grad)
    #print('in')
    #time.sleep(100)
    feats.extend(features_B_Z.tolist())
    logits_N_C = logit_B_C
    return logits_N_C, labels_N, feats


def gmm_get_logits(gmm, embeddings):
    log_probs_B_Y = gmm.log_prob(embeddings[:, None, :])
    return log_probs_B_Y


def gmm_fit(embeddings, labels, num_classes):
    # print(embeddings.dtype) #tiny: torch.float64
    with torch.no_grad():
        classwise_mean_features = torch.stack([torch.mean(embeddings[labels == c], dim=0) for c in range(num_classes)])
        print("classwise_mean_features", classwise_mean_features.shape)  # num_classes * dim_features
        #print(classwise_mean_features)
        classwise_cov_features = torch.stack(
            [centered_cov_torch(embeddings[labels == c] - classwise_mean_features[c]) for c in range(num_classes)]
        )
        print("classwise_cov_features", classwise_cov_features.shape)  # num_classes * dim_features*dim_features

    gmm = None

    with torch.no_grad():
        for jitter_eps in JITTERS:
            '''jitter = jitter_eps * torch.eye(
                classwise_cov_features.shape[1], device=classwise_cov_features.device,
            ).unsqueeze(0)
            print("GMM fitting: jitter_eps = ", jitter_eps)
            gmm = torch.distributions.MultivariateNormal(
                loc=classwise_mean_features, covariance_matrix=(classwise_cov_features + jitter),
            )
            print(gmm)
            return gmm, jitter_eps'''
            try:
                #print(classwise_mean_features.get_device())
                #print(classwise_cov_features.get_device())
                jitter = jitter_eps * torch.eye(
                    classwise_cov_features.shape[1], device=classwise_cov_features.device,
                ).unsqueeze(0)
                #print("GMM fitting: jitter_eps = ", jitter_eps)
                gmm = torch.distributions.MultivariateNormal(
                    loc=classwise_mean_features, covariance_matrix=(classwise_cov_features + jitter),
                )
                #print(gmm)
                #return gmm, jitter_eps
                #print("GMM finished...")
                break
            except RuntimeError as e:
                # print(e)
                if "cholesky" in str(e):
                    continue
            except ValueError as e:
                # print(e)
                if "The parameter covariance_matrix has invalid values" in str(e):
                    continue
    print("GMM finished...")
    #print(gmm)
    return gmm, jitter_eps



def get_logits_labels_allICs(model, data_loader, device):
    """
    Utility function to get logits and labels.
    """
    model.to(device)
    model.eval()

    logits_allICs = []
    labels = []

    with torch.no_grad():
        for data, label in data_loader:
            data = data.to(device)
            label = label.to(device)

            logit_allICs_batch = model(data)  # a list with 7 tensors of [128,200]
            tmp_batch_tensor = torch.stack(logit_allICs_batch)  # a tensor IC*batchExamples*classes
            logits_allICs.append(tmp_batch_tensor)

            labels.append(label)

    logits_allICs = torch.cat(logits_allICs, dim=1)
    labels = torch.cat(labels, dim=0)

    return logits_allICs, labels


# def get_roc_auc(net, test_loader, ood_test_loader, uncertainty, device, confidence=False):
#     logits, _ = get_logits_labels(net, test_loader, device)
#     ood_logits, _ = get_logits_labels(net, ood_test_loader, device)
#
#     return get_roc_auc_logits(logits, ood_logits, uncertainty, device, confidence=confidence)
def logsumexp(logits):
    return torch.logsumexp(logits, dim=1, keepdim=False)
def get_ood_labels(logits, ood_logits, device,uncertainty, confidence=False):
    uncertainties = logsumexp(logits)
    print('ood_logits ',ood_logits.size())
    ood_uncertainties = logsumexp(ood_logits)
    print('ood_uncertainties ',ood_uncertainties.size())

    # In-distribution
    bin_labels = torch.zeros(uncertainties.shape[0]).to(device)
    in_scores = uncertainties

    # OOD
    bin_labels = torch.cat((bin_labels, torch.ones(ood_uncertainties.shape[0]).to(device)))

    if confidence:
        bin_labels = 1 - bin_labels

    tmp=torch.quantile(in_scores,0.05)
    ood_scores = ood_uncertainties  # entropy(ood_logits)
    #print(ood_scores)
    #print(tmp)
    out2 = (ood_scores < tmp).float()
    #scores = torch.cat((in_scores, ood_scores))

    #print(tmp)
    #scores=torch.exp(scores)
    #scores=(scores-torch.min(scores))/(torch.max(scores)-torch.min(scores))
    #scores = scores/torch.sum(scores)

    #print(scores)

    #out1=(ood_scores>=tmp).float()

    #fpr, tpr, thresholds = metrics.roc_curve(bin_labels.cpu().numpy(), scores.cpu().numpy())
    #precision, recall, prc_thresholds = metrics.precision_recall_curve(bin_labels.cpu().numpy(), scores.cpu().numpy())
    #auroc = metrics.roc_auc_score(bin_labels.cpu().numpy(), scores.cpu().numpy())
    #auprc = metrics.average_precision_score(bin_labels.cpu().numpy(), scores.cpu().numpy())
    #out2
    return out2


def get_roc_auc_logits(logits, ood_logits, uncertainty, device, confidence=False):
    uncertainties = uncertainty(logits)
    ood_uncertainties = uncertainty(ood_logits)

    # In-distribution
    print('ood_uncertainties ',ood_uncertainties.size())
    bin_labels = torch.zeros(uncertainties.shape[0]).to(device)
    in_scores = uncertainties

    # OOD
    bin_labels = torch.cat((bin_labels, torch.ones(ood_uncertainties.shape[0]).to(device)))

    if confidence:
        bin_labels = 1 - bin_labels
    ood_scores = ood_uncertainties  # entropy(ood_logits)
    scores = torch.cat((in_scores, ood_scores))

    fpr, tpr, thresholds = metrics.roc_curve(bin_labels.cpu().numpy(), scores.cpu().numpy())
    precision, recall, prc_thresholds = metrics.precision_recall_curve(bin_labels.cpu().numpy(), scores.cpu().numpy())
    auroc = metrics.roc_auc_score(bin_labels.cpu().numpy(), scores.cpu().numpy())
    auprc = metrics.average_precision_score(bin_labels.cpu().numpy(), scores.cpu().numpy())

    return (fpr, tpr, thresholds), (precision, recall, prc_thresholds), auroc, auprc

'''def get_roc_auc_logits(logits, ood_logits, uncertainty, device, confidence=False):
    uncertainties = uncertainty(logits)
    ood_uncertainties = uncertainty(ood_logits)

    # In-distribution
    bin_labels = torch.zeros(uncertainties.shape[0]).to(device)
    in_scores = uncertainties

    # OOD
    bin_labels = torch.cat((bin_labels, torch.ones(ood_uncertainties.shape[0]).to(device)))

    if confidence:
        bin_labels = 1 - bin_labels

    #tmp=torch.quantile(in_scores,0.05)
    ood_scores = ood_uncertainties  # entropy(ood_logits)
    #print(ood_scores)
    #print(tmp)
    #out2 = (ood_scores < tmp).float()
    scores = torch.cat((in_scores, ood_scores))

    #print(tmp)
    #scores=torch.exp(scores)
    #scores=(scores-torch.min(scores))/(torch.max(scores)-torch.min(scores))
    #scores = scores/torch.sum(scores)

    #print(scores)

    #out1=(ood_scores>=tmp).float()

    fpr, tpr, thresholds = metrics.roc_curve(bin_labels.cpu().numpy(), scores.cpu().numpy())
    precision, recall, prc_thresholds = metrics.precision_recall_curve(bin_labels.cpu().numpy(), scores.cpu().numpy())
    auroc = metrics.roc_auc_score(bin_labels.cpu().numpy(), scores.cpu().numpy())
    auprc = metrics.average_precision_score(bin_labels.cpu().numpy(), scores.cpu().numpy())
    #out2
    return (fpr, tpr, thresholds), (precision, recall, prc_thresholds), auroc, auprc'''

