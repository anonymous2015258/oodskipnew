import pickle
import numpy as np
file = open('/nas1-nfs1/home/mxh170530/truong/skipnet/cifar/results/train_skips.pkl', 'rb')

# dump information to that file
data = pickle.load(file)
print(data.keys())
print(np.asarray(data['skips']).shape)
print(np.asarray(data['label']).shape)
print(np.asarray(data['data']).shape)
label=data['label']
skips=data['skips']
label=np.expand_dims(label,axis=1)
#print(skips)
tmp=np.concatenate((label,skips),axis=1)
print(tmp)

