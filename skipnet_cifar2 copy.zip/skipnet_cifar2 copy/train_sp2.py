"""
Training file for training SkipNets for supervised pre-training stage
"""

from __future__ import print_function
from torch.utils.data import TensorDataset, DataLoader
import argparse
import logging
import os
import shutil
import time
import pickle
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
from prettytable import PrettyTable
from torch.autograd import Variable

import models2 as models
from data import prepare_test_data, prepare_train_data
import numpy as np
model_names = sorted(
    name
    for name in models.__dict__
    if name.islower()
    and not name.startswith("__")
    and callable(models.__dict__[name])
)
os.environ['CUDA_VISIBLE_DEVICES'] = "4,5"
device = 'cuda:0'
def one_hot_embedding(labels, num_classes=2):
    # Convert to One Hot Encoding
    labels=labels.long()
    y = torch.eye(num_classes)
    #print(y)
    return y[labels]
def parse_args():
    # hyper-parameters are from ResNet paper
    parser = argparse.ArgumentParser(
        description="PyTorch CIFAR10 training with gating"
    )
    parser.add_argument("cmd", choices=["train", "test"])
    parser.add_argument(
        "arch",
        metavar="ARCH",
        default="cifar10_rnn_gate_110",
        choices=model_names,
        help="model architecture: "
        + " | ".join(model_names)
        + " (default: cifar10_rnn_gate_110)",
    )
    parser.add_argument(
        "--gate-type",
        type=str,
        default="rnn",
        choices=["ff", "rnn"],
        help="gate type",
    )
    parser.add_argument(
        "--dataset",
        "-d",
        default="cifar10",
        type=str,
        choices=["cifar10", "cifar100"],
        help="dataset type",
    )
    parser.add_argument(
        "--workers",
        default=4,
        type=int,
        metavar="N",
        help="number of data loading workers (default: 4 )",
    )
    parser.add_argument(
        "--iters",
        default=64000,
        type=int,
        help="number of total iterations (default: 64,000)",
    )
    parser.add_argument(
        "--start-iter",
        default=0,
        type=int,
        help="manual iter number (useful on restarts)",
    )
    parser.add_argument(
        "--batch-size",
        default=128,
        type=int,
        help="mini-batch size (default: 128)",
    )
    parser.add_argument(
        "--lr", default=0.1, type=float, help="initial learning rate"
    )
    parser.add_argument("--momentum", default=0.9, type=float, help="momentum")
    parser.add_argument(
        "--weight-decay",
        default=1e-4,
        type=float,
        help="weight decay (default: 1e-4)",
    )
    parser.add_argument(
        "--print-freq",
        default=50,
        type=int,
        help="print frequency (default: 50)",
    )
    parser.add_argument(
        "--resume",
        default="/nas1-nfs1/data/mxh170530/skipnet_cifar2/save_checkpoints/model_best.pth.tar",
        type=str,
        help="path to latest checkpoint (default: None)",
    )
    parser.add_argument(
        "--pretrained",
        dest="pretrained",
        action="store_true",
        help="use pretrained model",
    )
    parser.add_argument(
        "--step-ratio",
        default=0.1,
        type=float,
        help="ratio for learning rate deduction",
    )
    parser.add_argument(
        "--warm-up",
        action="store_true",
        help="for n = 18, the model needs to warm up for 400 " "iterations",
    )
    parser.add_argument(
        "--save-folder",
        default="save_checkpoints",
        type=str,
        help="folder to save the checkpoints",
    )
    parser.add_argument(
        "--eval-every",
        default=1000,
        type=int,
        help="evaluate model every (default: 1000) iterations",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="print layer skipping ratio at training",
    )

    args = parser.parse_args()
    return args


def main():
    args = parse_args()

    save_path = args.save_path = os.path.join(args.save_folder, args.arch)
    os.makedirs(save_path, exist_ok=True)

    # config logger file
    args.logger_file = os.path.join(save_path, "log_{}.txt".format(args.cmd))
    handlers = [
        logging.FileHandler(args.logger_file, mode="w"),
        logging.StreamHandler(),
    ]
    logging.basicConfig(
        level=logging.INFO,
        datefmt="%m-%d-%y %H:%M",
        format="%(asctime)s:%(message)s",
        handlers=handlers,
    )

    if args.cmd == "train":
        logging.info("start training {}".format(args.arch))
        run_training(args)

    elif args.cmd == "test":
        logging.info(
            "start evaluating {} with checkpoints from {}".format(
                args.arch, args.resume
            )
        )
        test_model(args)

def get_data():
    file = open('/nas1-nfs1/home/mxh170530/truong/skipnet/cifar/results/train_skips.pkl', 'rb')

    # dump information to that file
    data = pickle.load(file)
    skips=data['skips']
    data2 = data['data']
    label=data['label']
    tensor_x=torch.Tensor(data2)
    label = np.expand_dims(label, axis=1)
    # print(skips)
    tmp = np.concatenate((label, skips), axis=1)
    tensor_y = torch.Tensor(tmp).long()


    my_dataset = TensorDataset(tensor_x, tensor_y)
    my_dataloader = DataLoader(my_dataset,batch_size=128, shuffle=True, num_workers=1)
    return my_dataloader


def kl_divergence(alpha, num_classes, device=None):

    ones = torch.ones([1, num_classes], dtype=torch.float32, device=device)
    sum_alpha = torch.sum(alpha, dim=2, keepdim=True)
    #print(alpha[0])
    #print((alpha - ones)[0])
    first_term = (
        torch.lgamma(sum_alpha)
        - torch.lgamma(alpha).sum(dim=2, keepdim=True)
        + torch.lgamma(ones).sum(dim=1, keepdim=True)
        - torch.lgamma(ones.sum(dim=1, keepdim=True))
    )
    #print((alpha - ones).mul(torch.digamma(alpha) - torch.digamma(sum_alpha)))
    second_term = (
        (alpha - ones)
        .mul(torch.digamma(alpha) - torch.digamma(sum_alpha))
        .sum(dim=2, keepdim=True)
    )
    kl = first_term + second_term
    return kl
def relu_evidence(y):

    relu=torch.nn.ReLU(inplace=True)
    return relu(y)
def edl_loss(func, y, alpha, epoch_num, num_classes, annealing_step, device=None):
    y = y.to(device)
    alpha = alpha.to(device)
    #print(alpha)
    S = torch.sum(alpha, dim=2, keepdim=True)
    #print(alpha.size())
    #print(y.size())


    '''print(S.size())
    print(alpha.view(1, -1).size())
    print(torch.log(S).size())
    print(y.size())
    print((torch.log(S)-torch.log(alpha)).size())
    print(y*(torch.log(S)-torch.log(alpha)))'''
    #y=y.view(1, -1)

    A = torch.sum(y * (func(S) - func(alpha)), dim=2, keepdim=True)
    #A = torch.sum(y * (torch.subtract(func(S[0]) , func(alpha[0]))), dim=1, keepdim=True)
    #print(A)


    annealing_coef = torch.min(
        torch.tensor(1.0, dtype=torch.float32),
        torch.tensor(epoch_num / annealing_step, dtype=torch.float32),
    )

    kl_alpha = (alpha - 1) * (1 - y) + 1
    kl_div = annealing_coef * kl_divergence(kl_alpha, num_classes, device=device)
    return A + kl_div
def edl_log_loss(output, target, epoch_num, num_classes, annealing_step, device=None):

    evidence = relu_evidence(output)
    alpha = evidence + 1
    loss = torch.mean(
        edl_loss(
            torch.log, target, alpha, epoch_num, num_classes, annealing_step, device
        )
    )
    return loss
def run_training(args):
    # create model
    model = models.__dict__[args.arch](args.pretrained)
    model = torch.nn.DataParallel(model).cuda()

    best_prec1 = 0

    # optionally resume from a checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            logging.info("=> loading checkpoint `{}`".format(args.resume))
            checkpoint = torch.load(args.resume)
            args.start_iter = checkpoint["iter"]
            best_prec1 = checkpoint["best_prec1"]
            model.load_state_dict(checkpoint["state_dict"])
            logging.info(
                "=> loaded checkpoint `{}` (iter: {})".format(
                    args.resume, checkpoint["iter"]
                )
            )
        else:
            logging.info("=> no checkpoint found at `{}`".format(args.resume))

    cudnn.benchmark = True

    '''train_loader = prepare_train_data(
        dataset=args.dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.workers,
    )'''
    test_loader = prepare_test_data(
        dataset=args.dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
    )
    train_loader=get_data()

    # define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda()

    optimizer = torch.optim.SGD(
        filter(lambda p: p.requires_grad, model.parameters()),
        args.lr,
        momentum=args.momentum,
        weight_decay=args.weight_decay,
    )

    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    skip_ratios = ListAverageMeter()

    skips_table = PrettyTable()

    end = time.time()
    args.start_iter=0
    for i in range(args.start_iter, args.iters):
        model.train()
        adjust_learning_rate(args, optimizer, i)

        input, all_target = next(iter(train_loader))
        # measuring data loading time
        data_time.update(time.time() - end)
        target=all_target[:,:1]

        target=torch.squeeze(target,1)
        #print(target)


        target = target.cuda()
        input_var = Variable(input).cuda()
        target_var = Variable(target).cuda()

        # compute output
        output, masks, logprobs = model(input_var)
        #print(len(masks))


        #print([t.size() for t in logprobs])
        #b=torch.Tensor((1,128,2))
        del logprobs[-1]
        #print(len(logprobs))
        #time.sleep(100)
        b=logprobs[0]
        for idx in range(1,len(logprobs)):
            b=torch.cat((b,logprobs[idx]),dim=1)
            #print(b.size())
        #b=torch.cat(logprobs,dim=0)
        #b=b.resize_(128,54,2)
        #print(b[0][0])
        b=torch.reshape(b, (128,53,2))
        #b=torch.Tensor(logprobs)
        #print(b[0][0])

        #time.sleep(1000)

        # collect skip ratio of each layer
        skips = [mask.data.le(0.5).float().mean() for mask in masks]
        #n = np.zeros(shape=(len(input_var), 54))
        target_masks=all_target[:,1:]
        target_oh=one_hot_embedding(target_masks)
        tmp = 50000 / args.batch_size
        #print('i/tmp ', i / tmp)
        loss2 = edl_log_loss(
            b, target_oh.float(), i / tmp, 2, 10, device)
        #print(loss2)
        #time.sleep(1000)
        if skip_ratios.len != len(skips):
            skip_ratios.set_len(len(skips))

        loss = criterion(output, target_var)
        loss+=loss2
        # measure accuracy and record loss
        (prec1,) = accuracy(output.data, target, topk=(1,))
        losses.update(loss.item(), input.size(0))
        top1.update(prec1.item(), input.size(0))
        skip_ratios.update(skips, input.size(0))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        batch_time.update(time.time() - end)
        end = time.time()

        # print log
        if i % args.print_freq == 0 or i == (args.iters - 1):
            skips_table.add_column(
                "Gate Num", [f"{i:02}" for i in range(skip_ratios.len)]
            )
            skips_table.add_column("Gate Skip Val", skip_ratios.values)
            skips_table.add_column("Gate Skip Avg", skip_ratios.averages)
            logging.info("\n" + skips_table.get_string())
            skips_table.clear()

            logging.info(
                "Iter: [{0}/{1}]\t"
                "Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t"
                "Data {data_time.val:.3f} ({data_time.avg:.3f})\t"
                "Loss {loss.val:.3f} ({loss.avg:.3f})\t"
                "Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t".format(
                    i,
                    args.iters,
                    batch_time=batch_time,
                    data_time=data_time,
                    loss=losses,
                    top1=top1,
                )
            )

        # evaluate every 1000 steps
        if (i % args.eval_every == 0 and i > 0) or (i == (args.iters - 1)):
            prec1 = validate(args, test_loader, model, criterion)
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)
            checkpoint_path = os.path.join(
                args.save_path, "checkpoint_{:05d}.pth.tar".format(i)
            )
            save_checkpoint(
                {
                    "iter": i,
                    "arch": args.arch,
                    "state_dict": model.state_dict(),
                    "best_prec1": best_prec1,
                },
                is_best,
                filename=checkpoint_path,
            )
            shutil.copyfile(
                checkpoint_path,
                os.path.join(args.save_path, "checkpoint_latest" ".pth.tar"),
            )


def validate(args, test_loader, model, criterion):
    batch_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    skip_ratios = ListAverageMeter()

    # switch to evaluation mode
    model.eval()
    end = time.time()
    for i, (input, target) in enumerate(test_loader):
        target = target.cuda()
        input_var = Variable(input, volatile=True).cuda()
        target_var = Variable(target, volatile=True).cuda()
        # compute output
        output, masks, _ = model(input_var)
        skips = [mask.data.le(0.5).float().mean() for mask in masks]
        if skip_ratios.len != len(skips):
            skip_ratios.set_len(len(skips))
        loss = criterion(output, target_var)

        # measure accuracy and record loss
        (prec1,) = accuracy(output.data, target, topk=(1,))
        top1.update(prec1.item(), input.size(0))
        skip_ratios.update(skips, input.size(0))
        losses.update(loss.item(), input.size(0))
        batch_time.update(time.time() - end)
        end = time.time()

        if i % args.print_freq == 0 or (i == (len(test_loader) - 1)):
            logging.info(
                "Test: [{}/{}]\t"
                "Time: {batch_time.val:.4f}({batch_time.avg:.4f})\t"
                "Loss: {loss.val:.3f}({loss.avg:.3f})\t"
                "Prec@1: {top1.val:.3f}({top1.avg:.3f})\t".format(
                    i,
                    len(test_loader),
                    batch_time=batch_time,
                    loss=losses,
                    top1=top1,
                )
            )
    logging.info(
        " * Prec@1 {top1.avg:.3f}, Loss {loss.avg:.3f}".format(
            top1=top1, loss=losses
        )
    )

    skip_summaries = []
    for idx in range(skip_ratios.len):
        # logging.info(
        #     "{} layer skipping = {:.3f}".format(
        #         idx,
        #         skip_ratios.avg[idx],
        #     )
        # )
        skip_summaries.append(1 - skip_ratios.avg[idx])
    # compute `computational percentage`
    cp = ((sum(skip_summaries) + 1) / (len(skip_summaries) + 1)) * 100
    logging.info("*** Computation Percentage: {:.3f} %".format(cp))

    return top1.avg


def test_model(args):
    # create model
    model = models.__dict__[args.arch](args.pretrained)
    model = torch.nn.DataParallel(model).cuda()

    if args.resume:
        if os.path.isfile(args.resume):
            logging.info("=> loading checkpoint `{}`".format(args.resume))
            checkpoint = torch.load(args.resume)
            args.start_iter = checkpoint["iter"]
            _ = checkpoint["best_prec1"]
            model.load_state_dict(checkpoint["state_dict"])
            logging.info(
                "=> loaded checkpoint `{}` (iter: {})".format(
                    args.resume, checkpoint["iter"]
                )
            )
        else:
            logging.info("=> no checkpoint found at `{}`".format(args.resume))

    cudnn.benchmark = False
    test_loader = prepare_test_data(
        dataset=args.dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
    )
    criterion = nn.CrossEntropyLoss().cuda()

    validate(args, test_loader, model, criterion)


def save_checkpoint(state, is_best, filename="checkpoint.pth.tar"):
    torch.save(state, filename)
    if is_best:
        save_path = os.path.dirname(filename)
        shutil.copyfile(
            filename, os.path.join(save_path, "model_best.pth.tar")
        )


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


class ListAverageMeter(object):
    """Computes and stores the average and current values of a list"""

    def __init__(self):
        self.len = 10000  # set up the maximum length
        self.reset()

    def reset(self):
        self.val = [0] * self.len
        self.avg = [0] * self.len
        self.sum = [0] * self.len
        self.count = 0

    def set_len(self, n):
        self.len = n
        self.reset()

    def update(self, vals, n=1):
        assert len(vals) == self.len, "length of vals not equal to self.len"
        self.val = vals
        for i in range(self.len):
            self.sum[i] += self.val[i] * n
        self.count += n
        for i in range(self.len):
            self.avg[i] = self.sum[i] / self.count

    @property
    def values(self):
        return [round(v.cpu().item(), 3) for v in self.val]

    @property
    def averages(self):
        return [round(v.cpu().item(), 3) for v in self.avg]


def adjust_learning_rate(args, optimizer, _iter):
    """divide lr by 10 at 32k and 48k"""
    if args.warm_up and (_iter < 400):
        lr = 0.01
    elif 32000 <= _iter < 48000:
        lr = args.lr * (args.step_ratio**1)
    elif _iter >= 48000:
        lr = args.lr * (args.step_ratio**2)
    else:
        lr = args.lr

    if _iter % args.eval_every == 0:
        logging.info("Iter [{}] learning rate = {}".format(_iter, lr))

    for param_group in optimizer.param_groups:
        param_group["lr"] = lr


def accuracy(output, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    maxk = max(topk)
    batch_size = target.size(0)

    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))

    res = []
    for k in topk:
        correct_k = correct[:k].view(-1).float().sum(0)
        res.append(correct_k.mul_(100.0 / batch_size))
    return res


if __name__ == "__main__":
    main()
